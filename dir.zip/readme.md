## before push to firefox
```
cd src
update version number
zip -r dir.zip . -x '**/.*' -x '**/__MACOSX' -x '.DS_Store'    
```
